# Space Shooter Infinity (Proyecto)

Versión pro arcade colorido — HTML5 Canvas, con integración opcional a Firebase (Realtime DB) para leaderboard y presencia.

## Archivos
- `index.html` : página principal
- `style.css` : estilos
- `js/game.js` : código del juego
- `js/firebase-config.js` : pega aquí tu Firebase web config
- `js/net-firebase.js` : integración optional con Firebase

## Deploy en GitHub Pages (pasos rápidos)
1. Crear repositorio público `space-shooter-infinity`.
2. Subir todos los archivos.
3. En Settings → Pages → Source → main / (root) → Save.
4. Esperar la URL `https://TUUSUARIO.github.io/space-shooter-infinity/`.

## Integración Firebase (opcional)
1. Console Firebase → Add project → crear.
2. Add web app → copia el config y pégalo en `js/firebase-config.js`.
3. En Realtime Database → Crear base de datos → modo de prueba (temporal) o reglas seguras.
4. Activa `window.FIREBASE_CONFIG` en el archivo para habilitar online.

## Notas
- GitHub Pages y Google Sites son gratis.
- Firebase tiene plan gratuito suficiente para pruebas y modos casuales; revisa límites.
